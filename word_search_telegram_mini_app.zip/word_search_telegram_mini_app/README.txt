WORD SEARCH TELEGRAM MINI APP — 3 TILLI

Bu versiya Telegram ichida Web App / Mini App sifatida ochiladi:
- Telegram bot foydalanuvchiga "Word Search o‘ynash" tugmasini ko‘rsatadi.
- Tugma HTML mini app'ni Telegram ichida ochadi.
- O‘yin interfeysi o‘zbek, ingliz va rus tillarida.
- So‘zning birinchi va oxirgi harfini bosib topiladi.
- Har bir topilgan so‘z 10 ochko.

FAYLLAR
- bot.py: Telegram bot kodi (aiogram 3)
- webapp/index.html: mini app o‘yini
- requirements.txt: Python kutubxonalari
- .env.example: sozlama namunasi

ISHGA TUSHIRISH

1) Mini App HTML faylini HTTPS manzilga joylang.
   Masalan: GitHub Pages yoki HTTPS beradigan hosting. `webapp/index.html`
   faylining internetda ochiladigan to‘liq URL manzili kerak.

2) Telegram’da @BotFather orqali bot yarating:
   /newbot
   Bot tokenini oling.

3) @BotFather ichida mini app domenini sozlang:
   /newdomain buyrug‘idan foydalanib, HTTPS saytingiz domenini ulang.
   BotFather menyusi va mavjud sozlamalari farq qilishi mumkin.

4) Shu papkadan `.env.example` nusxa olib `.env` deb nomlang.
   Ichiga quyidagilarni kiriting:
   BOT_TOKEN=TOKENINGIZ
   WEBAPP_URL=https://saytingiz.example/index.html

5) Python 3.10+ o‘rnatilgan muhitda:
   pip install -r requirements.txt
   python bot.py

6) Telegram’da botni oching va /start yuboring. "Word Search o‘ynash"
   tugmasi mini app'ni ochadi.

MUHIM
- Telegram Mini App URL manzili HTTPS bo‘lishi shart.
- Bot va mini app ikki qismdan iborat: Python bot va joylangan HTML sahifa.
- Tokenni oshkor qilmang va GitHub'ga yuklamang.
- Ushbu versiya o‘yin natijalarini server bazasida saqlamaydi; ular mini app ochiq turgan vaqt uchun.
- Bot jarayoni ishlayotgan bo‘lishi kerak. Mini app HTML esa HTTPS hostingda doimiy turadi.
