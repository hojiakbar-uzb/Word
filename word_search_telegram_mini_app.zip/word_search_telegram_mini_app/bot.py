import os
import asyncio
from aiogram import Bot, Dispatcher
from aiogram.filters import CommandStart
from aiogram.types import Message, InlineKeyboardMarkup, WebAppInfo
from aiogram.utils.keyboard import InlineKeyboardBuilder
from dotenv import load_dotenv

load_dotenv()
BOT_TOKEN = os.getenv("BOT_TOKEN")
WEBAPP_URL = os.getenv("WEBAPP_URL")

async def main():
    if not BOT_TOKEN:
        raise RuntimeError("BOT_TOKEN .env faylida ko‘rsatilmagan.")
    if not WEBAPP_URL or not WEBAPP_URL.startswith("https://"):
        raise RuntimeError("WEBAPP_URL .env faylida HTTPS mini app manzili bo‘lishi kerak.")

    bot = Bot(BOT_TOKEN)
    dp = Dispatcher()

    @dp.message(CommandStart())
    async def start(message: Message):
        kb = InlineKeyboardBuilder()
        kb.button(text="🎮 Word Search o‘ynash", web_app=WebAppInfo(url=WEBAPP_URL))
        markup: InlineKeyboardMarkup = kb.as_markup()
        await message.answer(
            "🔎 <b>Word Search</b> mini app'iga xush kelibsiz!\\n"
            "O‘zbek, ingliz yoki rus tilini tanlab, yashirilgan so‘zlarni toping.",
            reply_markup=markup,
            parse_mode="HTML",
        )

    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())
